// Activates the Carousel
$('.carousel').carousel({
    interval: 5000
});