## TODO
- Add link to pdf of brochure (with pdf icon)
- Add hover effect on home page projects
- Figure out a way to filter projects by clicking company buttons 
- Complete individual projects page
- Add Gardabani and Outotec photos
- Photos on online distributed storage or local? 
- Add Google Analytics before publishing
- Change .section-colored class background to .section-colored rgba(199, 199, 199, 0.5) and maybe add subtle borders
